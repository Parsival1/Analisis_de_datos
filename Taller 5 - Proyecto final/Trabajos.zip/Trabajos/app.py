from flask import Flask, render_template, request
import joblib
import os
import numpy as np

app = Flask(__name__)

#Obtén el directorio actual
directorio_actual = os.path.dirname(os.path.abspath(__file__))

#Construye la ruta completa al archivo del modelo
ruta_modelo = os.path.join(directorio_actual, 'models', 'prediccion_medica.pkl')

#Cargar el modelo utilizando la ruta completa
model = joblib.load(ruta_modelo)

# Definir la ruta principal del sitio web
@app.route('/')
def index():
    return render_template('index.html')  # Renderizar la plantilla 'index.html'

# Definir la ruta para realizar la predicción
@app.route('/predict', methods=['POST'])
def predict():
    # Obtener los valores del formulario enviado
    Genero = int(request.form['Genero'])
    Fiebre = int(request.form['Fiebre'])
    Tos = int(request.form['Tos'])
    Dolor_garganta = int(request.form['Dolor_garganta'])
    Congestion_nasal = int(request.form['Congestion_nasal'])
    Dificultad_respiratoria = int(request.form['Dificultad_respiratoria'])
    
    pred_probabilities = np.array([[Genero, Fiebre, Tos, Dolor_garganta, Congestion_nasal, Dificultad_respiratoria]])
    
    prediccion = model.predict(pred_probabilities)

    mensaje = f"Segun los sintomas que esta presentando apuntan a que posiblemente tiene: {prediccion}"

    # Renderizar la plantilla 'result.html' y pasar el mensaje a la plantilla
    return render_template('result.html', pred=mensaje)

# Iniciar la aplicación si este script es el punto de entrada
if __name__ == '__main__':
    app.run()  # Iniciar la aplicación Flask